<?php

$conn = mysqli_connect("us-cdbr-east-02.cleardb.com", "b6f1489cd7bc19", "a8269e5e", "heroku_b1bbb4a322a6c43");

?>