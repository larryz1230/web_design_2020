
<?php
header("Location: /html/zhi_index.php");
die();
?>

<!-- 
This is a php redirect to my index page, zhi_index.php.
My 5 pages are zhi_index.php, zhi_home.php, zhi_campus.html, zhi_pages.html, and zhi_games.html.
 -->